compile the code with c++ compiler.
While running it pass directory path as comand line argument.
Make sure that directory path should contain file named "thefile.txt" with necessary commands to run.
Whatever path is passed in argument is directly appended to file name with no modifications so mind backslash.